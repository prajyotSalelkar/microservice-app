import React, { useMemo, useState } from "react";
import { useShop } from "../ShopContext";
import ProductCard from "../components/ProductCard";
import SidebarWishlist from "../components/SidebarWishlist";

export default function Home() {
  const { products, offline, loading } = useShop();
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return products;
    return products.filter((p) =>
      [p.name, p.description, p.category].some((x) => String(x || "").toLowerCase().includes(q))
    );
  }, [products, query]);

  return (
    <section>
      <div style={{ display: "flex", gap: 18, alignItems: "flex-start" }}>
        <div style={{ flex: "1 1 auto" }}>
          <div className="hero">
            <span className="eyebrow">New arrivals, softly lit</span>
            <h1>Shop that shifts with your mood, from dawn to dusk.</h1>
            <p>
              Browse a small, thoughtfully curated catalog. Tap the dial in the top right to slide the whole
              shop from pastel morning to moody night.
            </p>

            <div className="chip-row" style={{ margin: "16px 0 0" }}>
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search products…"
                style={{
                  flex: "1 1 220px",
                  minWidth: 220,
                  padding: "10px 14px",
                  borderRadius: 12,
                  border: "1px solid var(--border)",
                  background: "var(--surface-soft)",
                  color: "var(--text)",
                  outline: "none",
                }}
              />
              {query ? (
                <button className="chip active" onClick={() => setQuery("")}>Clear</button>
              ) : null}
            </div>
          </div>

          {offline && (
            <p className="offline-banner">
              Showing demo products — connect the backend + MongoDB to see your real catalog.
            </p>
          )}

          {loading ? (
            <p>Loading products…</p>
          ) : filtered.length === 0 ? (
            <div className="empty-state">
              <h3>No products found</h3>
              <p>Try a different search.</p>
            </div>
          ) : (
            <div className="grid">
              {filtered.map((p) => (
                <ProductCard key={p._id} product={p} />
              ))}
            </div>
          )}
        </div>

        <div style={{ width: 320, flex: "0 0 auto" }}>
          <SidebarWishlist />
        </div>
      </div>
    </section>
  );
}

