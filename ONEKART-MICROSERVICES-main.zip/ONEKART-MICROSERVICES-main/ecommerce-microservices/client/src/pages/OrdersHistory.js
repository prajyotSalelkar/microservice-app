import React, { useEffect, useState } from "react";
import { useShop } from "../ShopContext";
import { useNavigate } from "react-router-dom";

function OrderRow({ item }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
      <span style={{ color: "var(--text)" }}>
        {item.name || "Item"} <span style={{ color: "var(--text-soft)" }}>× {item.qty}</span>
      </span>
      <span style={{ color: "var(--text)" }}>
        ${(Number(item.price) * Number(item.qty)).toFixed(2)}
      </span>
    </div>
  );
}

export default function OrdersHistory() {
  const navigate = useNavigate();
  const { currentUser, offline, getOrdersForUser } = useShop();

  const [orders, setOrders] = useState([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      if (!currentUser?._id) return;
      setBusy(true);
      try {
        const data = await getOrdersForUser(currentUser._id);
        if (!cancelled) setOrders(Array.isArray(data) ? data : []);
      } catch {
        if (!cancelled) setOrders([]);
      } finally {
        if (!cancelled) setBusy(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [currentUser, getOrdersForUser]);

  return (
    <section>
      <div className="hero">
        <span className="eyebrow">Your orders</span>
        <h1>History</h1>
      </div>

      {!currentUser?._id ? (
        <div className="empty-state">
          <h3>Sign in first</h3>
          <p>Go to Profile to sign in and view your order history.</p>
          <button className="btn-primary" onClick={() => navigate("/profile")}>
            Go to Profile
          </button>
        </div>
      ) : (
        <>
          {offline ? (
            <p className="offline-banner">Backend offline — order history not available.</p>
          ) : null}

          {busy ? (
            <p>Loading orders…</p>
          ) : orders.length === 0 ? (
            <div className="empty-state">
              <h3>No orders yet</h3>
              <p>Place an order from Checkout to see it here.</p>
            </div>
          ) : (
            <div style={{ display: "grid", gap: 18 }}>
              {orders.map((order) => (
                <div key={order._id} className="profile-card" style={{ textAlign: "left" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 14 }}>
                    <strong style={{ fontSize: 16 }}>Order</strong>
                    <strong style={{ fontSize: 16 }}>${Number(order.total).toFixed(2)}</strong>
                  </div>

                  <div style={{ marginTop: 12, color: "var(--text-soft)", fontSize: 13 }}>
                    Placed: {order.createdAt ? new Date(order.createdAt).toLocaleString() : "—"}
                  </div>

                  <div style={{ marginTop: 14, display: "grid", gap: 8 }}>
                    {(order.items || []).map((it, idx) => (
                      <OrderRow key={it.product?._id || it.product || idx} item={it} />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </section>
  );
}

