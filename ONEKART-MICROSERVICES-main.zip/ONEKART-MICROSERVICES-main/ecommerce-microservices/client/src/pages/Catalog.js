import React, { useMemo, useState } from "react";
import { useShop } from "../ShopContext";
import ProductCard from "../components/ProductCard";
import SidebarWishlist from "../components/SidebarWishlist";

// Catalog page with category chips that come from the actual catalog categories.
export default function Catalog() {
  const { products, categories, loading } = useShop();
  const [active, setActive] = useState("All");

  const filtered = useMemo(() => {
    if (active === "All") return products;
    return products.filter((p) => p.category === active);
  }, [products, active]);

  return (
    <section>
      <div style={{ display: "flex", gap: 18, alignItems: "flex-start" }}>
        <div style={{ flex: "1 1 auto" }}>
          <div className="hero">
            <span className="eyebrow">Explore by category</span>
            <h1>Everything, organized.</h1>
          </div>

          <div className="chip-row">
            <button
              className={`chip ${active === "All" ? "active" : ""}`}
              onClick={() => setActive("All")}
            >
              All
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                className={`chip ${active === cat ? "active" : ""}`}
                onClick={() => setActive(cat)}
              >
                {cat}
              </button>
            ))}
          </div>

          {loading ? (
            <p>Loading…</p>
          ) : filtered.length === 0 ? (
            <div className="empty-state">
              <h3>No items found</h3>
              <p>Try a different category.</p>
            </div>
          ) : (
            <div className="grid">
              {filtered.map((p) => (
                <ProductCard key={p._id} product={p} />
              ))}
            </div>
          )}
        </div>

        <div style={{ width: 320, flex: "0 0 auto" }}>
          <SidebarWishlist />
        </div>
      </div>
    </section>
  );
}

