import React, { useState, useMemo } from "react";
import { useShop } from "../ShopContext";
import ProductCard from "../components/ProductCard";

export default function Categories() {
  const { products, categories } = useShop();
  const [active, setActive] = useState("All");

  const filtered = useMemo(
    () => (active === "All" ? products : products.filter((p) => p.category === active)),
    [products, active]
  );

  return (
    <section>
      <div className="hero">
        <span className="eyebrow">Browse by category</span>
        <h1>Find exactly what you're after.</h1>
      </div>

      <div className="chip-row">
        <button className={`chip ${active === "All" ? "active" : ""}`} onClick={() => setActive("All")}>
          All
        </button>
        {categories.map((cat) => (
          <button key={cat} className={`chip ${active === cat ? "active" : ""}`} onClick={() => setActive(cat)}>
            {cat}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="empty-state">
          <h3>Nothing here yet</h3>
          <p>Try a different category.</p>
        </div>
      ) : (
        <div className="grid">
          {filtered.map((p) => (
            <ProductCard key={p._id} product={p} />
          ))}
        </div>
      )}
    </section>
  );
}
