import React, { useEffect, useState } from "react";
import { useShop } from "../ShopContext";
import { useNavigate } from "react-router-dom";
import ProductImage from "../components/ProductImage";

export default function Cart() {
  const navigate = useNavigate();
  const { currentUser, offline, getCart, removeFromCart, updateCartQty, clearCart, feedbackMessage, setFeedbackMessage } = useShop();

  // NOTE: ShopContext currently does not expose cart methods.
  // This page will only work after we add cart methods to ShopContext.
  // Keeping it here for now so the UI compiles once we wire it.

  const [cart, setCart] = useState({ items: [], total: 0 });
  const [busy, setBusy] = useState(false);

  async function refreshCart() {
    if (!currentUser?._id) return;
    const data = await getCart(currentUser._id);
    setCart(data);
  }

  useEffect(() => {
    let cancelled = false;

    async function load() {
      if (!currentUser?._id) {
        setCart({ items: [], total: 0 });
        return;
      }
      try {
        const data = await getCart(currentUser._id);
        if (!cancelled) setCart(data);
      } catch {
        if (!cancelled) setCart({ items: [], total: 0 });
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [currentUser, getCart]);

  const canCheckout = cart.items.length > 0;

  return (
    <section>
      <div className="hero">
        <span className="eyebrow">Your cart</span>
        <h1>Checkout ready.</h1>
      </div>

      {!currentUser?._id ? (
        <div className="empty-state">
          <h3>Sign in first</h3>
          <p>Go to Profile to sign in (demo Google works) so we can save your cart.</p>
        </div>
      ) : (
        <>
          {offline ? (
            <p className="offline-banner">Backend offline — cart will not sync.</p>
          ) : null}

          {feedbackMessage ? (
            <p className="offline-banner" style={{ marginBottom: 16 }}>{feedbackMessage}</p>
          ) : null}

          {cart.items.length === 0 ? (
            <div className="empty-state">
              <h3>Your cart is empty</h3>
              <p>Add items from the catalog.</p>
            </div>
          ) : (
            <>
              <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))" }}>
                {cart.items.map(({ product, quantity }) => (
                  <div key={product._id} className="card">
                    <div className="card-media">
                      <ProductImage product={product} />
                    </div>
                    <div className="card-body">
                      <span className="card-category">{product.category}</span>
                      <h3 className="card-title">{product.name}</h3>
                      <span className="card-price">${Number(product.price).toFixed(2)}</span>

                      <div style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 10 }}>
                        <button
                          className="chip"
                          onClick={async () => {
                            setBusy(true);
                            try {
                              await updateCartQty(currentUser._id, product._id, Math.max(1, quantity - 1));
                              await refreshCart();
                              setFeedbackMessage(`Updated quantity for ${product.name}.`);
                            } finally {
                              setBusy(false);
                            }
                          }}
                          disabled={busy}
                        >
                          -
                        </button>
                        <strong>{quantity}</strong>
                        <button
                          className="chip"
                          onClick={async () => {
                            setBusy(true);
                            try {
                              await updateCartQty(currentUser._id, product._id, quantity + 1);
                              await refreshCart();
                              setFeedbackMessage(`Updated quantity for ${product.name}.`);
                            } finally {
                              setBusy(false);
                            }
                          }}
                          disabled={busy}
                        >
                          +
                        </button>
                      </div>

                      <button
                        className="btn-primary"
                        style={{ marginTop: 14, background: "linear-gradient(135deg, var(--accent), var(--accent-2))" }}
                        onClick={async () => {
                          setBusy(true);
                          try {
                            await removeFromCart(currentUser._id, product._id);
                            await refreshCart();
                            setFeedbackMessage(`Removed ${product.name} from cart.`);
                          } finally {
                            setBusy(false);
                          }
                        }}
                        disabled={busy}
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ maxWidth: 520, margin: "28px auto 0" }}>
                <div className="profile-card" style={{ padding: 22, textAlign: "left" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <strong style={{ fontSize: 18 }}>Total</strong>
                    <strong style={{ fontSize: 18 }}>${Number(cart.total).toFixed(2)}</strong>
                  </div>
                  <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
                    <button
                      className="btn-primary"
                      onClick={async () => {
                        navigate("/checkout");
                      }}
                      disabled={!canCheckout}
                    >
                      Checkout
                    </button>
                    <button
                      className="chip"
                      onClick={async () => {
                        setBusy(true);
                        try {
                          await clearCart(currentUser._id);
                          setCart({ items: [], total: 0 });
                          setFeedbackMessage("Cart cleared.");
                        } finally {
                          setBusy(false);
                        }
                      }}
                      disabled={busy}
                    >
                      Clear
                    </button>
                  </div>
                </div>
              </div>
            </>
          )}
        </>
      )}
    </section>
  );
}

