import React, { useEffect, useState } from "react";
import { useShop } from "../ShopContext";

const STORAGE_KEY = "demoProfile";

function loadProfile() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : { name: "", email: "", bio: "" };
  } catch {
    return { name: "", email: "", bio: "" };
  }
}

// Small styled modal used for the demo Google sign-in instead of window.prompt().
function GoogleSignInModal({ onCancel, onSubmit, busy }) {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    if (!email.trim()) return;
    onSubmit({ email: email.trim(), name: name.trim() });
  }

  return (
    <div className="modal-overlay" onClick={onCancel}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <h3>Continue with Google</h3>
        <p>This is a demo sign-in — no real Google account is contacted. Enter any email to try it.</p>
        <form onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="g-email">Email</label>
            <input
              id="g-email"
              type="email"
              autoFocus
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="field">
            <label htmlFor="g-name">Name</label>
            <input
              id="g-name"
              placeholder="Your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="modal-actions">
            <button type="button" className="chip" onClick={onCancel} disabled={busy} style={{ flex: 1 }}>
              Cancel
            </button>
            <button type="submit" className="btn-primary" disabled={busy} style={{ flex: 1 }}>
              {busy ? "Signing in…" : "Continue"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// Confirmation modal for permanently deleting the account.
function DeleteAccountModal({ userEmail, onCancel, onConfirm, busy }) {
  const [confirmText, setConfirmText] = useState("");
  const canDelete = confirmText.trim().toLowerCase() === (userEmail || "").toLowerCase();

  return (
    <div className="modal-overlay" onClick={onCancel}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <h3>Delete your account?</h3>
        <p>
          This permanently deletes your profile, cart, and wishlist from the database. This
          can't be undone. Type your email (<strong>{userEmail}</strong>) to confirm.
        </p>
        <div className="field">
          <label htmlFor="confirm-email">Email</label>
          <input
            id="confirm-email"
            autoFocus
            value={confirmText}
            onChange={(e) => setConfirmText(e.target.value)}
            placeholder={userEmail}
          />
        </div>
        <div className="modal-actions">
          <button type="button" className="chip" onClick={onCancel} disabled={busy} style={{ flex: 1 }}>
            Cancel
          </button>
          <button
            type="button"
            className="btn-danger"
            onClick={onConfirm}
            disabled={!canDelete || busy}
            style={{ flex: 1 }}
          >
            {busy ? "Deleting…" : "Delete account"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Profile() {
  const {
    currentUser,
    login,
    updateProfile,
    logout,
    deleteAccount,
    feedbackMessage,
    setFeedbackMessage,
    offline,
    googleLogin,
  } = useShop();

  const [profile, setProfile] = useState(loadProfile);
  const [saving, setSaving] = useState(false);
  const [showGoogleModal, setShowGoogleModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  useEffect(() => {
    if (currentUser?._id) {
      setProfile((prev) => ({
        ...prev,
        name: currentUser.name ?? prev.name,
        email: currentUser.email ?? prev.email,
        bio: currentUser.bio ?? prev.bio,
      }));
    }
  }, [currentUser]);

  function handleChange(field, value) {
    setProfile((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    try {
      if (currentUser?._id) {
        await updateProfile({ name: profile.name, email: profile.email, bio: profile.bio });
      } else {
        await login({ name: profile.name, email: profile.email, bio: profile.bio });
      }
      localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
      setFeedbackMessage("Signed in.");
    } catch (err) {
      setFeedbackMessage(err.message || "Could not sign in.");
    } finally {
      setSaving(false);
    }
  }

  async function handleGoogleSubmit({ email, name }) {
    setSaving(true);
    try {
      await googleLogin({ email, name, bio: "" });
      setProfile((p) => ({ ...p, name: name || p.name, email }));
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ name, email, bio: "" }));
      setShowGoogleModal(false);
      setFeedbackMessage("Signed in with Google.");
    } catch (err) {
      setFeedbackMessage(err.message || "Google sign-in failed.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDeleteConfirm() {
    setSaving(true);
    try {
      await deleteAccount();
      localStorage.removeItem(STORAGE_KEY);
      setProfile({ name: "", email: "", bio: "" });
      setShowDeleteModal(false);
    } catch (err) {
      setFeedbackMessage(err.message || "Could not delete account.");
    } finally {
      setSaving(false);
    }
  }

  const initial = (currentUser?.name || profile.name || "?").trim().charAt(0).toUpperCase();

  // ---------- Signed OUT view ----------
  if (!currentUser?._id) {
    return (
      <section>
        <div className="hero">
          <span className="eyebrow">Your account</span>
          <h1>Sign in</h1>
        </div>

        {offline && (
          <p className="offline-banner">Backend offline — sign-in won't sync to the database right now.</p>
        )}

        <div className="auth-card">
          <div className="auth-icon">🔐</div>
          <h3>Welcome back</h3>
          <p style={{ color: "var(--text-soft)", fontSize: "0.9rem", marginTop: 4 }}>
            Sign in to save your wishlist and cart.
          </p>

          <button
            type="button"
            className="btn-google"
            onClick={() => setShowGoogleModal(true)}
            disabled={saving}
          >
            <span aria-hidden="true">🟢</span> Continue with Google
          </button>

          <div className="auth-divider">or</div>

          <form onSubmit={handleSave} style={{ textAlign: "left" }}>
            <div className="field">
              <label htmlFor="name">Name</label>
              <input
                id="name"
                value={profile.name}
                onChange={(e) => handleChange("name", e.target.value)}
                placeholder="Jamie Rivera"
                required
              />
            </div>
            <div className="field">
              <label htmlFor="email">Email</label>
              <input
                id="email"
                type="email"
                value={profile.email}
                onChange={(e) => handleChange("email", e.target.value)}
                placeholder="jamie@example.com"
                required
              />
            </div>
            <button className="btn-primary" type="submit" disabled={saving}>
              {saving ? "Signing in…" : "Sign in / Create account"}
            </button>
          </form>

          {feedbackMessage ? <p className="offline-banner" style={{ marginTop: 16 }}>{feedbackMessage}</p> : null}
        </div>

        {showGoogleModal && (
          <GoogleSignInModal
            busy={saving}
            onCancel={() => setShowGoogleModal(false)}
            onSubmit={handleGoogleSubmit}
          />
        )}
      </section>
    );
  }

  // ---------- Signed IN view ----------
  return (
    <section>
      <div className="hero">
        <span className="eyebrow">Your account</span>
        <h1>Profile</h1>
      </div>

      {offline && (
        <p className="offline-banner">Backend offline — profile changes won't sync to wishlist.</p>
      )}

      <form className="profile-card" onSubmit={handleSave}>
        <div className="profile-avatar">{initial}</div>

        <div className="field">
          <label htmlFor="name">Name</label>
          <input id="name" value={profile.name} onChange={(e) => handleChange("name", e.target.value)} />
        </div>

        <div className="field">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            type="email"
            value={profile.email}
            onChange={(e) => handleChange("email", e.target.value)}
          />
        </div>

        <div className="field">
          <label htmlFor="bio">Bio</label>
          <textarea id="bio" rows={3} value={profile.bio} onChange={(e) => handleChange("bio", e.target.value)} />
        </div>

        <button className="btn-primary" type="submit" disabled={saving}>
          {saving ? "Saving…" : "Save changes"}
        </button>

        <button
          type="button"
          className="chip"
          style={{ marginTop: 12, width: "100%" }}
          onClick={() => {
            logout();
            setFeedbackMessage("Signed out.");
          }}
          disabled={saving}
        >
          Sign out
        </button>

        {feedbackMessage ? <p className="offline-banner" style={{ marginTop: 16 }}>{feedbackMessage}</p> : null}

        <div className="danger-zone">
          <h4>Danger zone</h4>
          <p>Permanently delete your account, cart, and wishlist. This can't be undone.</p>
          <button
            type="button"
            className="btn-danger"
            onClick={() => setShowDeleteModal(true)}
            disabled={saving}
          >
            Delete account
          </button>
        </div>
      </form>

      {showDeleteModal && (
        <DeleteAccountModal
          userEmail={currentUser.email}
          busy={saving}
          onCancel={() => setShowDeleteModal(false)}
          onConfirm={handleDeleteConfirm}
        />
      )}
    </section>
  );
}
