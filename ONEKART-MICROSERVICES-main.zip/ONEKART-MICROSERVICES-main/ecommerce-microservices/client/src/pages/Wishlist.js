import React from "react";
import { useShop } from "../ShopContext";
import ProductCard from "../components/ProductCard";

export default function Wishlist() {
  const { wishlist } = useShop();

  const items = wishlist
    .map((w) => (w.product && w.product._id ? w.product : null))
    .filter(Boolean);

  return (
    <section>
      <div className="hero">
        <span className="eyebrow">Saved for later</span>
        <h1>Your wishlist ❤️</h1>
      </div>

      {items.length === 0 ? (
        <div className="empty-state">
          <h3>Your wishlist is empty</h3>
          <p>Tap the heart on any product to save it here.</p>
        </div>
      ) : (
        <div className="grid">
          {items.map((p) => (
            <ProductCard key={p._id} product={p} />
          ))}
        </div>
      )}
    </section>
  );
}
