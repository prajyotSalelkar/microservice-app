import React, { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { useShop } from "../ShopContext";
import ProductImage from "../components/ProductImage";

export default function ProductDetails() {
  const { id } = useParams();

  const {
    products,
    offline,
    loading,
    isWishlisted,
    toggleWishlist,
    getItemMessage,
    showItemMessage,
    userId,
    addToCart,
    getProduct,
  } = useShop();

  const localProduct = useMemo(
    () => products.find((p) => String(p._id) === String(id)) || null,
    [products, id]
  );

  const [remoteProduct, setRemoteProduct] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      if (offline) return;
      if (!id) return;
      if (typeof getProduct !== "function") return;

      try {
        setBusy(true);
        const p = await getProduct(id);
        if (!cancelled) setRemoteProduct(p);
      } catch {
        // best-effort
      } finally {
        if (!cancelled) setBusy(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [id, offline, getProduct]);

  const product = remoteProduct || localProduct;

  const wishlisted = product ? isWishlisted(product._id) : false;
  const itemMessage = product ? getItemMessage(product._id) : "";

  if (loading && !product) {
    return (
      <section>
        <p>Loading…</p>
      </section>
    );
  }

  if (!product) {
    return (
      <section>
        <div className="empty-state">
          <h3>Product not found</h3>
          <p>Try going back to the catalog.</p>
        </div>
      </section>
    );
  }

  return (
    <section>
      <div className="hero">
        <span className="eyebrow">Product details</span>
        <h1>{product.name}</h1>
      </div>

      {offline ? (
        <p className="offline-banner">Backend offline — showing cached/demo data.</p>
      ) : null}

      <div
        className="profile-card"
        style={{
          maxWidth: 860,
          marginTop: 10,
          textAlign: "left",
          display: "flex",
          gap: 22,
          flexWrap: "wrap",
        }}
      >
        <div style={{ flex: "1 1 320px" }}>
          <div
            style={{
              background: "var(--surface-soft)",
              borderRadius: "var(--radius)",
              overflow: "hidden",
              border: "1px solid var(--border)",
            }}
          >
            <ProductImage
              product={product}
              style={{ width: "100%", height: "auto", minHeight: 260, display: "block", objectFit: "cover" }}
            />
          </div>
        </div>

        <div style={{ flex: "1 1 360px" }}>
          <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 16 }}>
            <span className="card-category">{product.category}</span>
            <span className="card-price">${Number(product.price).toFixed(2)}</span>
          </div>

          {product.description ? (
            <p className="card-desc" style={{ fontSize: "1rem", marginTop: 10 }}>
              {product.description}
            </p>
          ) : null}

          {typeof product.stock === "number" ? (
            <p style={{ color: "var(--text-soft)", marginTop: 6 }}>Stock: {product.stock}</p>
          ) : null}

          <div style={{ display: "flex", gap: 12, marginTop: 18, flexWrap: "wrap" }}>
            <button
              className="btn-primary"
              style={{ width: "auto", padding: "12px 18px" }}
              disabled={!userId}
              onClick={async () => {
                if (!userId) {
                  showItemMessage(product._id, "Sign in first to add items to cart.");
                  return;
                }
                try {
                  await addToCart(userId, product._id, 1);
                  showItemMessage(product._id, `Added ${product.name} to cart.`);
                } catch (err) {
                  showItemMessage(product._id, err.message || "Could not add to cart.");
                }
              }}
            >
              Add to cart
            </button>

            <button className="chip" onClick={() => toggleWishlist(product)}>
              {wishlisted ? "Remove from wishlist" : "Save to wishlist"}
            </button>
          </div>

          {itemMessage ? (
            <p className="offline-banner" style={{ marginTop: 14 }}>
              {itemMessage}
            </p>
          ) : null}

          {busy ? <p style={{ marginTop: 10, color: "var(--text-soft)" }}>Loading details…</p> : null}
        </div>
      </div>
    </section>
  );
}

