import React, { useEffect, useState } from "react";

function buildFallbackImage(product) {
  const seed = encodeURIComponent(product?._id || product?.name || "product");
  return `https://picsum.photos/seed/${seed}/600/450`;
}

export default function ProductImage({ product, className, style, loading = "lazy" }) {
  const fallbackImage = buildFallbackImage(product);
  const primaryImage = product?.image || fallbackImage;
  const [src, setSrc] = useState(primaryImage);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setSrc(primaryImage);
    setFailed(false);
  }, [primaryImage]);

  if (failed) {
    return (
      <div
        className={className}
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          width: "100%",
          height: "100%",
          color: "var(--text-soft)",
          fontWeight: 700,
          ...style,
        }}
      >
        No image
      </div>
    );
  }

  return (
    <img
      className={className}
      src={src}
      alt={product?.name || "Product"}
      loading={loading}
      style={style}
      onError={() => {
        if (src !== fallbackImage) {
          setSrc(fallbackImage);
          return;
        }
        setFailed(true);
      }}
    />
  );
}