import React from "react";
import { Link } from "react-router-dom";
import { useShop } from "../ShopContext";
import ProductImage from "./ProductImage";

export default function SidebarWishlist() {
  const { wishlist } = useShop();

  const items = wishlist
    .map((w) => (w.product && w.product._id ? w.product : null))
    .filter(Boolean);

  return (
    <aside
      style={{
        position: "sticky",
        top: 90,
        alignSelf: "start",
        padding: 14,
        borderRadius: "var(--radius)",
        background: "var(--surface-soft)",
        border: "1px solid var(--border)",
        boxShadow: "0 10px 30px -18px var(--shadow)",
      }}
    >
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 10 }}>
        <div>
          <div className="eyebrow" style={{ letterSpacing: "0.12em" }}>
            Wishlist
          </div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 18, fontWeight: 800 }}>
            {items.length} saved
          </div>
        </div>

        <Link className="chip" to="/wishlist" style={{ textDecoration: "none" }}>
          View
        </Link>
      </div>

      <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 10 }}>
        {items.length === 0 ? (
          <p style={{ margin: 0, color: "var(--text-soft)", fontSize: 13 }}>
            Tap the heart 🤍 on a product.
          </p>
        ) : (
          items.slice(0, 5).map((p) => (
            <div key={p._id} style={{ display: "flex", gap: 10, alignItems: "center" }}>
              <div
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 12,
                  overflow: "hidden",
                  border: "1px solid var(--border)",
                  background: "var(--surface)",
                  flex: "0 0 auto",
                }}
              >
                <ProductImage product={p} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 800, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                  {p.name}
                </div>
                <div style={{ fontSize: 12, color: "var(--text-soft)" }}>${Number(p.price).toFixed(2)}</div>
              </div>
            </div>
          ))
        )}
      </div>
    </aside>
  );
}

