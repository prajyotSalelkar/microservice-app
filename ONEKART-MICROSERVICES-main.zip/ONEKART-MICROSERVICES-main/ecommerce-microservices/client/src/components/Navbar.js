import React from "react";
import { NavLink } from "react-router-dom";

export default function Navbar({ theme, onToggleTheme }) {
  return (
    <header className="navbar">
      <div className="brand">
        <span className="brand-mark" aria-hidden="true" />
        1Kart

      </div>

      <nav className="nav-links">
        <NavLink to="/" end className={({ isActive }) => (isActive ? "active" : "")}>
          Home
        </NavLink>
        <NavLink to="/categories" className={({ isActive }) => (isActive ? "active" : "")}>
          Categories
        </NavLink>
        <NavLink to="/wishlist" className={({ isActive }) => (isActive ? "active" : "")}>
          Wishlist
        </NavLink>
        <NavLink to="/cart" className={({ isActive }) => (isActive ? "active" : "")}> 
          Cart
        </NavLink>
        <NavLink to="/profile" className={({ isActive }) => (isActive ? "active" : "")}>
          Profile
        </NavLink>
        <NavLink to="/orders" className={({ isActive }) => (isActive ? "active" : "")}>
          Orders
        </NavLink>
      </nav>

      <button
        className="dusk-dial"
        onClick={onToggleTheme}
        aria-label={`Switch to ${theme === "dawn" ? "dusk" : "dawn"} mode`}
        title={`Switch to ${theme === "dawn" ? "dusk" : "dawn"} mode`}
      >
        <span className="knob">{theme === "dawn" ? "☀️" : "🌙"}</span>
      </button>
    </header>
  );
}
