require("dotenv").config();
const express = require("express");
const cors = require("cors");
const { createProxyMiddleware } = require("http-proxy-middleware");

const app = express();

/**
 * ---------------------------------------------------------------------
 * SERVICE REGISTRY
 * ---------------------------------------------------------------------
 * Each entry is: route prefix -> list of upstream URLs.
 * Giving a prefix MORE THAN ONE url is what makes this "load balanced":
 * the gateway will round-robin requests across every url listed, so you
 * can run 2+ copies of the same microservice (different ports, or
 * different machines) and the gateway spreads traffic across them.
 *
 * Configure via .env, e.g.:
 *   PRODUCT_SERVICE_URLS=http://localhost:5002,http://localhost:5012
 * ---------------------------------------------------------------------
 */
function parseUrls(envVar, fallback) {
  return (process.env[envVar] || fallback)
    .split(",")
    .map((u) => u.trim())
    .filter(Boolean);
}

const registry = {
  "/api/profile": parseUrls("USER_SERVICE_URLS", "http://localhost:5001"),
  "/api/google": parseUrls("USER_SERVICE_URLS", "http://localhost:5001"),
  "/api/products": parseUrls("PRODUCT_SERVICE_URLS", "http://localhost:5002"),
  "/api/cart": parseUrls("CART_SERVICE_URLS", "http://localhost:5003"),
  "/api/orders": parseUrls("ORDER_SERVICE_URLS", "http://localhost:5004"),
  "/api/wishlist": parseUrls("WISHLIST_SERVICE_URLS", "http://localhost:5005"),
  "/api/checkout": parseUrls("PAYMENT_SERVICE_URLS", "http://localhost:5006"),
};

// Round-robin counters, one per route prefix
const counters = {};
function pickUpstream(prefix) {
  const urls = registry[prefix];
  counters[prefix] = (counters[prefix] || 0) % urls.length;
  const chosen = urls[counters[prefix]];
  counters[prefix] += 1;
  return chosen;
}

app.use(
  cors({ origin: process.env.CORS_ORIGIN || "http://localhost:3000", credentials: true })
);

// Gateway-level request log - useful to SEE the load balancing happen
app.use((req, res, next) => {
  console.log(`[gateway] ${req.method} ${req.originalUrl}`);
  next();
});

// Simple status page listing every registered service and its instances
app.get("/gateway/status", (req, res) => {
  res.json({ gateway: "ok", registry });
});

// Register one proxy per route prefix. The `router` option is called on
// EVERY incoming request, so pickUpstream() runs fresh each time -> that
// is the round-robin load balancing step.
Object.keys(registry).forEach((prefix) => {
  app.use(
    prefix,
    createProxyMiddleware({
      changeOrigin: true,
      router: () => pickUpstream(prefix),
      pathRewrite: (path, req) => req.originalUrl, // keep the full /api/... path
      onError: (err, req, res) => {
        console.error(`[gateway] upstream error for ${prefix}:`, err.message);
        res.status(502).json({ error: "Upstream service unavailable", service: prefix });
      },
    })
  );
});

app.get("/", (req, res) => {
  res.send("1KART API Gateway is running. See /gateway/status for routing table.");
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`[gateway] listening on http://localhost:${PORT}`));
