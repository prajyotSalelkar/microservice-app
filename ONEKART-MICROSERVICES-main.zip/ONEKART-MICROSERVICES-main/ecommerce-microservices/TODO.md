- [ ] Update frontend API URL via client/.env to point at API gateway (http://localhost:8080/api)
- [ ] Restart backend (`npm run dev` at repo root) and restart frontend (`cd client && npm start`)
- [ ] Trigger Pay flow and confirm payment-service logs show cart-service response
- [ ] If checkout still fails, use added payment-service logs to locate root cause (empty cart vs upstream routing vs ObjectId cast)

