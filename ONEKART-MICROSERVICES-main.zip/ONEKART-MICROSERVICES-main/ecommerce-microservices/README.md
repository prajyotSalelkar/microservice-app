# 1KART — API Gateway + Microservices (with Payments)

Your monolithic `server/` is now 6 independent services behind one
lightweight API Gateway, all sharing one MongoDB database. The React
client is included too, with the one line changed that's needed to route
checkout through the new payment service.

## Architecture

```
                         ┌─────────────────────┐
   React client  ───────▶│   API Gateway :8080  │
   (port 3000)           │  (routing + LB only) │
                         └──────────┬───────────┘
                                    │ round-robins across instances
   ┌──────────┬────────────┬───────┼────────┬────────────┬────────────┐
   ▼          ▼            ▼       ▼        ▼            ▼            
user-svc   product-svc  cart-svc order-svc wishlist-svc payment-svc
 :5001        :5002       :5003    :5004      :5005        :5006
   │            │            │        │          │            │  │
   └────────────┴────────────┴────────┴──────────┴────────────┘  │
                                    │                    HTTP calls to
                            one shared MongoDB          cart-svc & order-svc
                         (Atlas cluster or local mongod)
```

Each service is its own Node/Express process, own `package.json`, own
port. All connect to the **same** `MONGO_URI` (per your requirement of one
shared DB) — except `payment-service`, which deliberately talks to
`cart-service` and `order-service` over HTTP instead of sharing their
models (see below).

## Folder structure

```
ecommerce-microservices/
├── client/                  # your React app, unchanged except 1 file
│   └── src/api.js           # placeOrder() now calls /checkout, not /orders
├── gateway/                 # single entry point, port 8080
│   ├── server.js
│   ├── package.json
│   └── .env.example
├── services/
│   ├── user-service/        # profile + google auth, port 5001
│   ├── product-service/     # products catalog + seed.js, port 5002
│   ├── cart-service/        # cart, port 5003
│   ├── order-service/       # orders, port 5004
│   ├── wishlist-service/    # wishlist, port 5005
│   └── payment-service/     # checkout/payment, port 5006  ← NEW
│       ├── server.js
│       ├── models/Payment.js
│       ├── routes/checkout.js
│       ├── package.json
│       └── .env.example
└── package.json             # root helper to run everything at once (dev only)
```

Every backend service kept the **exact same route paths** as your
monolith (`/api/products`, `/api/cart`, etc.), so the gateway forwards
requests through untouched.

## Payment is its own service, on purpose

`payment-service` is the one deliberate exception to the "shared models"
approach used everywhere else. Payment data (transaction IDs, gateway
responses, PCI-adjacent concerns) is exactly the kind of thing you want
isolated — separate deploys, separate scaling, separate audit trail, and
an easy swap-in point for a real gateway (Razorpay/Stripe) later without
touching any other service.

**Flow:** client calls `POST /api/checkout` →
1. payment-service asks `cart-service` for the current cart/total
2. "charges the card" (currently a mock function — swap in a real SDK call later)
3. on success, calls `order-service` (`POST /api/orders`) to create the order and clear the cart
4. saves its own `Payment` record, linked to that order
5. returns `{ payment, order }`

This is real inter-service communication over HTTP (via `axios`) — unlike
the other services, which still import each other's Mongoose models
directly since they share one DB.

**Client change already applied:** `client/src/api.js`'s `placeOrder()`
now calls `${API_URL}/checkout` instead of `${API_URL}/orders`, and sends
`{ userId, method: "mock_card" }`. It still returns just the `order`
object, so `Checkout.js` and `ShopContext.js` needed **zero** changes.

## Why one shared DB (and its trade-off)

You asked for a single DB, so every service (besides payment-service's
cross-service calls) keeps using the Mongoose models/routes you already
wrote — e.g. `cart-service` still does
`Cart.findOne(...).populate("items.product")`. This is the fastest,
lowest-risk way to go from monolith → microservices, since you don't
rewrite any business logic, only split *processes*.

The trade-off: a "purist" microservice setup would have every service
call the service that owns its data over HTTP (the way `payment-service`
already does), instead of importing models directly. Worth doing once
this version is stable and working — not required to get load balancing
today.

## Compass vs Atlas

Compass is a GUI only — it connects to whatever `mongod` you point it at.
Atlas is the actual cloud-hosted database. Once you have 6 separate
processes (possibly on different machines later), they all need one
`MONGO_URI` reachable over the network — that's Atlas. Keep using Compass
as your GUI, just point it at the same Atlas connection string.

## How the Gateway load-balances

`gateway/server.js` has a small registry: route prefix → list of upstream
URLs. On every request it round-robins through that list:

```js
"/api/products": parseUrls("PRODUCT_SERVICE_URLS", "http://localhost:5002"),
```

List **two** URLs for the same service (e.g. run `product-service` twice,
on 5002 and 5012) and the gateway alternates between both — real load
balancing, no external tool needed. `/gateway/status` shows the live
routing table.

## Step-by-step setup

### 1. Get MongoDB reachable
Use your Atlas connection string (see the Atlas section above), formatted
like:
```
mongodb+srv://<user>:<password>@<cluster>.mongodb.net/ecommerce?retryWrites=true&w=majority
```

### 2. Configure every service
Copy `.env.example` → `.env` in `gateway/` and **all 6** folders under
`services/`. Put the **same** Atlas `MONGO_URI` in every service's `.env`.
Ports are pre-set (5001–5006), gateway is 8080.

`payment-service/.env` additionally needs (already defaulted, only change
if you rename ports):
```
CART_SERVICE_URL=http://localhost:5003
ORDER_SERVICE_URL=http://localhost:5004
```

### 3. Configure the client
Copy `client/.env.example` → `client/.env`:
```
REACT_APP_API_URL=http://localhost:8080/api
```

### 4. Install dependencies
```bash
cd ecommerce-microservices
npm run install:all
cd client && npm install
```

### 5. Seed the database (optional but recommended)
```bash
cd services/product-service
npm run seed
```
This populates the `ecommerce` database with sample products using your
`MONGO_URI` — run once against your Atlas cluster.

### 6. Run the backend
From the root:
```bash
npm run dev
```
Boots the gateway + all 6 services with color-coded logs in one terminal.

### 7. Run the client
In a separate terminal:
```bash
cd client
npm start
```

### 8. Test the full checkout flow
Add an item to cart → go to Checkout → click Pay. Watch the terminal logs:
you'll see the request hit the gateway, then `payment-service`, which in
turn calls `cart-service` and `order-service` — all visible in the
color-coded logs.

### 9. Test load balancing (optional)
```bash
cd services/product-service
PORT=5012 node server.js
```
Then in `gateway/.env`:
```
PRODUCT_SERVICE_URLS=http://localhost:5002,http://localhost:5012
```
Restart the gateway and hit `/api/products` a few times — the logs
alternate between the two `product-service` instances.

### 10. Deploy each service independently
Each folder is a standalone Node app — deploy to separate
VMs/containers/Render/Railway instances, run multiple replicas of the
busiest ones (usually `product-service` and `cart-service`), and just
update the gateway's `.env` with their public URLs.

## Scaling beyond the built-in round-robin
- **PM2 cluster mode** — `pm2 start server.js -i max` inside any service folder, no code changes.
- **Nginx** in front of multiple gateway instances, once the gateway itself is the bottleneck.
- **Service discovery** (e.g. Consul) instead of hardcoded URLs, once you have many instances.
- **Database-per-service** — give services their own DB once you want true independence.

## Next hardening steps (not required to run)
- Add a real payment gateway SDK inside `payment-service/routes/checkout.js`'s `mockChargeCard()`.
- Add a shared JWT/auth check at the gateway.
- Add rate limiting at the gateway (`express-rate-limit`).
- Add centralized logging (all 6 services currently log to their own console only).
