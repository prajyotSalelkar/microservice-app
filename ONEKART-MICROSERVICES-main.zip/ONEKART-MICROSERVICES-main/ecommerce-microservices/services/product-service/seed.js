// Run with: npm run seed
require("dotenv").config();
const mongoose = require("mongoose");
const Product = require("./models/Product");

const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/ecommerce";

const sampleProducts = [
  // Kitchen / Home
  { name: "Marble Pour-Over Set", price: 29.99, category: "kitchen", image: "https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?w=500", description: "A calming pour-over starter set for slow mornings." },
  { name: "Ceramic Mug Trio", price: 22.0, category: "home", image: "https://images.unsplash.com/photo-1528823872057-9c018a7b8d2e?w=500", description: "Three handmade mugs in matching pastel tones." },
  { name: "Nonstick Skillet (8in)", price: 34.5, category: "appliances", image: "https://images.unsplash.com/photo-1519710164239-da123dc03ef4?w=500", description: "Quick heat, easy cleanup, everyday reliability." },
  { name: "Desk Kettle Warmer", price: 19.75, category: "appliances", image: "https://images.unsplash.com/photo-1507089947368-5d2e0e5f1b0f?w=500", description: "Keeps your drink warm while you work." },

  // Stationery / Office
  { name: "Pastel Gel Pen Pack", price: 12.99, category: "stationary", image: "https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=500", description: "Satisfying smooth gel pens for notes and doodles." },
  { name: "A5 Notebook — Linen Cover", price: 8.5, category: "stationary", image: "https://images.unsplash.com/photo-1519681393784-d120267933ba?w=500", description: "Lay-flat pages with a soft linen cover." },

  // Games / Tech / Random
  { name: "Pocket Trivia Card Deck", price: 14.25, category: "games", image: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=500", description: "Tiny deck, big conversations. Great for friends." },
  { name: "Retro Desk Lamp", price: 41.0, category: "decirtion", image: "https://images.unsplash.com/photo-1519710887722-0b4dcb4b3d8e?w=500", description: "Warm glow with a classic mid-century silhouette." },
  { name: "Wireless Keyboard Skin", price: 9.99, category: "tech", image: "https://images.unsplash.com/photo-1587825140708-dfaf4be5e1d8?w=500", description: "Protect and personalize your keyboard in seconds." },
  { name: "Mini USB Organizer", price: 11.5, category: "tech", image: "https://images.unsplash.com/photo-1607636345527-0c6f3b1d0d4f?w=500", description: "Tidy cables and adapters—always find what you need." },

  // Electronics / Home entertainment
  { name: "Soft-Sound Bluetooth Speaker", price: 49.99, category: "electronics", image: "https://images.unsplash.com/photo-1518441902117-f0a1e8f9f8b0?w=500", description: "Small speaker, surprisingly rich sound." },
  { name: "Desk Stand Fan", price: 27.25, category: "appliances", image: "https://images.unsplash.com/photo-1609613183599-4bf2d4e2d6e1?w=500", description: "Compact breeze for your workspace." },
  { name: "Satin Sleep Mask", price: 16.75, category: "wellness", image: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?w=500", description: "Soft satin finish for restful evenings." },
  { name: "Stoneware Dinner Bowl", price: 21.0, category: "home", image: "https://images.unsplash.com/photo-1610701596007-11502861dcfa?w=500", description: "Hand-finished bowl for everyday dinners." },
  { name: "Linen Throw Blanket", price: 34.5, category: "home", image: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=500", description: "Lightweight throw in a warm neutral tone." },
  { name: "Glass Aroma Diffuser", price: 28.25, category: "decor", image: "https://images.unsplash.com/photo-1603006905003-be475563bc59?w=500", description: "A minimal diffuser with a calm glow." },
  { name: "Travel Journal", price: 14.99, category: "stationary", image: "https://images.unsplash.com/photo-1517842645767-c639042777db?w=500", description: "Compact journal with a durable linen cover." },
  { name: "Portable Phone Stand", price: 19.5, category: "tech", image: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=500", description: "A tidy stand for work and video calls." },
  { name: "Velvet Desk Organizer", price: 22.99, category: "desk", image: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=500", description: "Elegant storage for pens, cords, and notes." },
  { name: "Mini Ceramic Planter", price: 17.5, category: "decor", image: "https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=500", description: "A petite planter for a calm desk corner." },
  { name: "Soft Knit Beanie", price: 19.0, category: "accessories", image: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=500", description: "Warm and cozy for cool mornings." },
  { name: "Studio Canvas Tote", price: 26.75, category: "bags", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500", description: "A roomy tote with a simple silhouette." },
  { name: "Amber Table Lamp", price: 54.25, category: "decor", image: "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=500", description: "Warm ambient light for reading nooks." },
  { name: "Laptop Sleeve", price: 29.9, category: "tech", image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=500", description: "Protective sleeve with a neat finish." },
  { name: "Ceramic Spoon Rest", price: 13.25, category: "kitchen", image: "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=500", description: "A minimal rest for your everyday prep tools." },
  { name: "Cozy Candle Set", price: 23.99, category: "wellness", image: "https://images.unsplash.com/photo-1603006905003-be475563bc59?w=500", description: "A calm scent pairing for your home." },
];


async function seed() {
  await mongoose.connect(MONGO_URI);
  console.log("Connected. Seeding products...");
  await Product.deleteMany({});
  await Product.insertMany(sampleProducts);
  console.log(`Inserted ${sampleProducts.length} products.`);
  await mongoose.disconnect();
  process.exit(0);
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
