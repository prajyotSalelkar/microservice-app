const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const Product = require('../models/Product');

// Create an order from the user's current cart, then clear the cart
router.post('/', async (req, res) => {
  try {
    const { userId } = req.body;
    const cart = await Cart.findOne({ user: userId }).populate('items.product');

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: 'Cart is empty' });
    }

    // Cart model uses { product, quantity }
    const items = cart.items.map((i) => ({
      product: i.product._id,
      name: i.product.name,
      price: i.product.price,
      qty: i.quantity,
    }));

    // Decrease stock for each ordered product (best-effort).
    // If stock is low, we still place the order (demo app), but we clamp at 0.
    await Promise.all(
      items.map(async (it) => {
        const product = await Product.findById(it.product);
        if (!product) return;
        product.stock = Math.max(0, (product.stock || 0) - it.qty);
        await product.save();
      })
    );

    const total = items.reduce((sum, i) => sum + i.price * i.qty, 0);

    const order = await Order.create({ user: userId, items, total });

    cart.items = [];
    await cart.save();

    res.status(201).json(order);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get a user's past orders (optional, useful for a future "My Orders" page)
router.get('/:userId', async (req, res) => {
  try {
    const orders = await Order.find({ user: req.params.userId }).sort({ createdAt: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;