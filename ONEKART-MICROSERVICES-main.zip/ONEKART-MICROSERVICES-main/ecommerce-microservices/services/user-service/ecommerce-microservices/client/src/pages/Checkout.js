import React, { useEffect, useState } from "react";
import { useShop } from "../ShopContext";
import { Link, useNavigate } from "react-router-dom";

export default function Checkout() {

  const navigate = useNavigate();
  const { currentUser, getCart, offline, placeOrder, setFeedbackMessage, feedbackMessage } = useShop();

  const [cart, setCart] = useState({ items: [], total: 0 });
  const [busy, setBusy] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      if (!currentUser?._id) return;
      try {
        const data = await getCart(currentUser._id);
        if (!cancelled) setCart(data);
      } catch {
        if (!cancelled) setCart({ items: [], total: 0 });
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [currentUser, getCart]);

  const canPay = cart.items.length > 0;

  return (
    <section>
      <div className="hero">
        <span className="eyebrow">Checkout</span>
        <h1>Place your order.</h1>
      </div>

      {offline ? (
        <p className="offline-banner">Backend offline — checkout not available.</p>
      ) : null}

      {orderPlaced ? (
        <div className="profile-card" style={{ padding: 24, maxWidth: 680 }}>
          <h2>🎉 You placed an order!</h2>
          <p>Thanks for shopping with 1Kart.</p>

          <div style={{ display: "flex", gap: 12, marginTop: 18, flexWrap: "wrap" }}>
            <button className="btn-primary" disabled={busy} onClick={() => navigate("/catalog")}>
              Continue shopping
            </button>
            <Link to="/orders" className="chip" style={{ display: "inline-flex", alignItems: "center" }}>
              View your order history
            </Link>
          </div>
        </div>
      ) : cart.items.length === 0 ? (

        <div className="empty-state">
          <h3>No items</h3>
          <p>Add items to cart first.</p>
        </div>
      ) : (
        <div className="profile-card" style={{ padding: 24, maxWidth: 680 }}>
          <div style={{ display: "flex", gap: 16, justifyContent: "space-between" }}>
            <strong style={{ fontSize: 18 }}>Order total</strong>
            <strong style={{ fontSize: 18 }}>${Number(cart.total).toFixed(2)}</strong>
          </div>

          <div style={{ marginTop: 18, color: "var(--text-soft)", lineHeight: 1.5 }}>
            <div style={{ fontWeight: 800, color: "var(--text)" }}>Items</div>
            {cart.items.map(({ product, quantity }) => (
              <div key={product._id} style={{ display: "flex", justifyContent: "space-between" }}>
                <span>
                  {product.name} × {quantity}
                </span>
                <span>${(product.price * quantity).toFixed(2)}</span>
              </div>
            ))}
          </div>

          <div style={{ display: "flex", gap: 12, marginTop: 22 }}>
            <button
              className="btn-primary"
              disabled={!canPay || busy}
              onClick={async () => {
                setBusy(true);
                try {
                  setFeedbackMessage("");
                  await placeOrder();
                  setOrderPlaced(true);
                  setFeedbackMessage("Payment done — your order was placed!");
                } catch (e) {
                  setFeedbackMessage(e?.message || "Payment failed.");
                } finally {
                  setBusy(false);
                }
              }}
            >
              {busy ? "Processing…" : "Pay"}
            </button>

            <button className="chip" disabled={busy} onClick={() => navigate("/cart")}>
              Back to cart
            </button>

          </div>
        </div>
      )}
    </section>
  );
}

