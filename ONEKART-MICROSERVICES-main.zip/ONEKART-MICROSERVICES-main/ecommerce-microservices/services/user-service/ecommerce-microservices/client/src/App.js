import React, { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Categories from "./pages/Categories";
import Wishlist from "./pages/Wishlist";
import Profile from "./pages/Profile";
import Catalog from "./pages/Catalog";
import Cart from "./pages/Cart";
import Checkout from "./pages/Checkout";
import ProductDetails from "./pages/ProductDetails";
import OrdersHistory from "./pages/OrdersHistory";
import { ShopProvider } from "./ShopContext";




export default function App() {
  const [theme, setTheme] = useState(() => localStorage.getItem("theme") || "dawn");

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme === "dusk" ? "dusk" : "dawn");
    localStorage.setItem("theme", theme);
  }, [theme]);

  function toggleTheme() {
    setTheme((t) => (t === "dawn" ? "dusk" : "dawn"));
  }

  return (
    <ShopProvider>
      <BrowserRouter>
        <Navbar theme={theme} onToggleTheme={toggleTheme} />
        <main className="app-shell">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/categories" element={<Categories />} />
            <Route path="/wishlist" element={<Wishlist />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/catalog" element={<Catalog />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/product/:id" element={<ProductDetails />} />
            <Route path="/orders" element={<OrdersHistory />} />

          </Routes>

        </main>
      </BrowserRouter>
    </ShopProvider>
  );
}
