import React from "react";
import { useShop } from "../ShopContext";

import { useNavigate } from "react-router-dom";

export default function ProductCard({ product }) {
  const navigate = useNavigate();
  const { isWishlisted, toggleWishlist, getItemMessage, showItemMessage, userId, addToCart } = useShop();
  const wishlisted = isWishlisted(product._id);
  const itemMessage = getItemMessage(product._id);

  return (
    <article
      className="card"
      onClick={() => navigate(`/product/${product._id}`)}
      style={{ cursor: "pointer" }}
    >
      <div className="card-media">
        {product.image ? (
          <img src={product.image} alt={product.name} loading="lazy" />
        ) : (
          <div
            style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%" }}
          >
            🛍️
          </div>
        )}

        <button
          className="wishlist-btn"
          onClick={(event) => {
            event.stopPropagation();
            toggleWishlist(product);
          }}
          aria-label={wishlisted ? "Remove from wishlist" : "Add to wishlist"}
          title={wishlisted ? "Remove from wishlist" : "Add to wishlist"}
        >
          {wishlisted ? "❤️" : "🤍"}
        </button>
      </div>

      <div className="card-body">
        <span className="card-category">{product.category}</span>
        <h3 className="card-title">{product.name}</h3>
        {product.description && <p className="card-desc">{product.description}</p>}
        <span className="card-price">${Number(product.price).toFixed(2)}</span>

        {typeof product.stock === "number" ? (
          <span style={{ color: "var(--text-soft)", fontSize: "0.82rem" }}>
            Stock: {product.stock}
          </span>
        ) : null}

        <div style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 10 }}>
          <button
            className="chip"
            onClick={async (event) => {
              event.stopPropagation();
              if (!userId) {
                showItemMessage(product._id, "Sign in first to add items to cart.");
                return;
              }
              try {
                await addToCart(userId, product._id, 1);
                showItemMessage(product._id, `Added ${product.name} to cart.`);
              } catch (err) {
                showItemMessage(product._id, err.message || "Could not add to cart.");
              }
            }}
            disabled={!userId}
            title={!userId ? "Sign in to add to cart" : "Add to cart"}
          >
            Add to cart
          </button>

          <span style={{ color: "var(--text-soft)", fontSize: "0.82rem" }}>
            {userId ? "Saved in DB cart" : "Sign in first"}
          </span>
        </div>

        {itemMessage ? (
          <span style={{ marginTop: 6, color: "var(--accent)", fontWeight: 700, fontSize: "0.82rem" }}>
            {itemMessage}
          </span>
        ) : null}
      </div>
      </article>
  );
}


