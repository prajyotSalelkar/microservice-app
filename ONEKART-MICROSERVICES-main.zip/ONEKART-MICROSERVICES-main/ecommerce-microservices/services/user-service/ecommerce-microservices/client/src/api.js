const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000/api";

async function request(path, options = {}) {
  const res = await fetch(`${API_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    throw new Error((data && data.error) || "Request failed");
  }
  return data;
}

export const api = {
  // Products
  getProducts: (category) => request(`/products${category ? `?category=${encodeURIComponent(category)}` : ""}`),
  getCategories: () => request("/products/categories"),
  getProduct: (id) => request(`/products/${id}`),

  // Wishlist
  getWishlist: (userId) => request(`/wishlist/${userId}`),
  addToWishlist: (userId, productId) =>
    request("/wishlist", {
      method: "POST",
      body: JSON.stringify({ user: userId, product: productId }),
    }),
  removeFromWishlist: (userId, productId) =>
    request(`/wishlist/${userId}/${productId}`, { method: "DELETE" }),

  // Profile
  getProfile: (id) => request(`/profile/${id}`),
  loginProfile: (body) =>
    request("/profile/login", { method: "POST", body: JSON.stringify(body) }),
  updateProfile: (id, body) =>
    request(`/profile/${id}`, { method: "PUT", body: JSON.stringify(body) }),
  deleteProfile: (id) => request(`/profile/${id}`, { method: "DELETE" }),

  // Google (demo / placeholder)
  googleLogin: (body) => request("/google/login", { method: "POST", body: JSON.stringify(body) }),

  // Cart
  getCart: (userId) => request(`/cart/${userId}`),
  addToCart: (userId, productId, quantity = 1) =>
    request("/cart/add", {
      method: "POST",
      body: JSON.stringify({ userId, productId, quantity }),
    }),
  removeFromCart: (userId, productId) =>
    request("/cart/remove", {
      method: "POST",
      body: JSON.stringify({ userId, productId }),
    }),
  updateCartQty: (userId, productId, quantity) =>
    request("/cart/update-qty", {
      method: "POST",
      body: JSON.stringify({ userId, productId, quantity }),
    }),
  clearCart: (userId) =>
    request("/cart/clear", {
      method: "POST",
      body: JSON.stringify({ userId }),
    }),

  // Orders
  getOrdersForUser: (userId) => request(`/orders/${userId}`),
};

// place order API - goes through payment-service now, which charges
// (mocked) then creates the order via order-service internally.
export async function placeOrder(userId) {
  const res = await fetch(`${API_URL}/checkout`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, method: "mock_card" }),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => null);
    throw new Error((data && data.message) || "Payment failed");
  }
  const { order } = await res.json();
  return order; // same shape ShopContext/Checkout.js already expect
}

