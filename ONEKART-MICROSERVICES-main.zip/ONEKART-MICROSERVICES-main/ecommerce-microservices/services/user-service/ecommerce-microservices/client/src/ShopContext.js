import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { api, placeOrder as placeOrderApi } from "./api";

const ShopContext = createContext(null);
const USER_STORAGE_KEY = "shopUser";

function loadStoredUser() {
  try {
    const raw = localStorage.getItem(USER_STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}




// Fallback sample data shown if the backend / MongoDB isn't running yet,
// so the UI is still browsable while you wire up the API.
const FALLBACK_PRODUCTS = [
  { _id: "demo-1", name: "Cloud Comfort Sneakers", price: 59.99, category: "Footwear", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500", description: "Lightweight everyday sneakers." },
  { _id: "demo-2", name: "Pastel Tote Bag", price: 24.5, category: "Bags", image: "https://images.unsplash.com/photo-1591561954557-26941169b49e?w=500", description: "Canvas tote in soft pastel pink." },
  { _id: "demo-3", name: "Minimalist Watch", price: 89.0, category: "Accessories", image: "https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=500", description: "Slim analog watch, leather strap." },
  { _id: "demo-4", name: "Wireless Earbuds", price: 39.99, category: "Electronics", image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=500", description: "Noise-isolating true wireless earbuds." },
  { _id: "demo-5", name: "Ceramic Mug Set", price: 18.0, category: "Home", image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=500", description: "Set of 2 pastel ceramic mugs." },
  { _id: "demo-6", name: "Cozy Knit Sweater", price: 45.0, category: "Clothing", image: "https://images.unsplash.com/photo-1576871337622-98d48d1cf531?w=500", description: "Soft oversized knit sweater." },
  { _id: "demo-7", name: "Satin Sleep Mask", price: 16.75, category: "Wellness", image: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?w=500", description: "Soft satin finish for restful evenings." },
  { _id: "demo-8", name: "Stoneware Dinner Bowl", price: 21.0, category: "Home", image: "https://images.unsplash.com/photo-1610701596007-11502861dcfa?w=500", description: "Hand-finished bowl for everyday dinners." },
  { _id: "demo-9", name: "Linen Throw Blanket", price: 34.5, category: "Home", image: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=500", description: "Lightweight throw in a warm neutral tone." },
  { _id: "demo-10", name: "Glass Aroma Diffuser", price: 28.25, category: "Decor", image: "https://images.unsplash.com/photo-1603006905003-be475563bc59?w=500", description: "A minimal diffuser with a calm glow." },
  { _id: "demo-11", name: "Travel Journal", price: 14.99, category: "Stationery", image: "https://images.unsplash.com/photo-1517842645767-c639042777db?w=500", description: "Compact journal with a durable linen cover." },
  { _id: "demo-12", name: "Portable Phone Stand", price: 19.5, category: "Tech", image: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=500", description: "A tidy stand for work and video calls." },
  { _id: "demo-13", name: "Velvet Desk Organizer", price: 22.99, category: "Desk", image: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=500", description: "Elegant storage for pens, cords, and notes." },
  { _id: "demo-14", name: "Mini Ceramic Planter", price: 17.5, category: "Decor", image: "https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=500", description: "A petite planter for a calm desk corner." },
  { _id: "demo-15", name: "Soft Knit Beanie", price: 19.0, category: "Accessories", image: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=500", description: "Warm and cozy for cool mornings." },
  { _id: "demo-16", name: "Studio Canvas Tote", price: 26.75, category: "Bags", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500", description: "A roomy tote with a simple silhouette." },
  { _id: "demo-17", name: "Amber Table Lamp", price: 54.25, category: "Decor", image: "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=500", description: "Warm ambient light for reading nooks." },
  { _id: "demo-18", name: "Laptop Sleeve", price: 29.9, category: "Tech", image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=500", description: "Protective sleeve with a neat finish." },
  { _id: "demo-19", name: "Ceramic Spoon Rest", price: 13.25, category: "Kitchen", image: "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=500", description: "A minimal rest for your everyday prep tools." },
  { _id: "demo-20", name: "Cozy Candle Set", price: 23.99, category: "Wellness", image: "https://images.unsplash.com/photo-1603006905003-be475563bc59?w=500", description: "A calm scent pairing for your home." },
];

function dedupeProducts(list = []) {
  const seen = new Set();
  const result = [];
  list.forEach((product) => {
    const key = product?._id || product?.id || product?.name;
    if (!key || seen.has(key)) return;
    seen.add(key);
    result.push(product);
  });
  return result;
}

export function ShopProvider({ children }) {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [wishlist, setWishlist] = useState([]); // array of { _id, product }
  const [currentUser, setCurrentUser] = useState(loadStoredUser);
  const [feedbackMessage, setFeedbackMessage] = useState("");
  const [offline, setOffline] = useState(false);
  const [loading, setLoading] = useState(true);
  const userId = currentUser?._id || "";

  // Per-product messages (e.g. "Added to wishlist") keyed by product id, so
  // the message only shows under the ONE card that was clicked instead of
  // under every card on the page.
  const [itemMessages, setItemMessages] = useState({});
  const itemMessageTimers = React.useRef({});

  const showItemMessage = useCallback((productId, text, duration = 2200) => {
    setItemMessages((prev) => ({ ...prev, [productId]: text }));
    if (itemMessageTimers.current[productId]) {
      clearTimeout(itemMessageTimers.current[productId]);
    }
    itemMessageTimers.current[productId] = setTimeout(() => {
      setItemMessages((prev) => {
        const next = { ...prev };
        delete next[productId];
        return next;
      });
    }, duration);
  }, []);

  const getItemMessage = useCallback((productId) => itemMessages[productId] || "", [itemMessages]);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const [prods, cats] = await Promise.all([api.getProducts(), api.getCategories()]);
        if (cancelled) return;
        // Real data from MongoDB succeeded — use it as-is. Do NOT blend in
        // FALLBACK_PRODUCTS here, since those have fake ids (e.g. "demo-1")
        // that are not valid MongoDB ObjectIds. Mixing them in was the cause
        // of "add/remove wishlist doesn't work for half the products": any
        // click on a fake-id product made the backend crash trying to save
        // an invalid ObjectId.
        const realProducts = dedupeProducts(prods);
        setProducts(realProducts);
        setCategories(cats.length ? cats : [...new Set(realProducts.map((p) => p.category))]);
        setOffline(false);
      } catch (err) {
        if (cancelled) return;
        // Backend / MongoDB truly not reachable — fall back to local demo
        // data so the UI is still browsable. Wishlist/cart actions on this
        // data stay local-only (see toggleWishlist's `offline` branch) and
        // are never sent to the server, so there's no ObjectId mismatch.
        setProducts(FALLBACK_PRODUCTS);
        setCategories([...new Set(FALLBACK_PRODUCTS.map((p) => p.category))]);
        setOffline(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!currentUser) {
      localStorage.removeItem(USER_STORAGE_KEY);
      setWishlist([]);
      return;
    }

    localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(currentUser));

    if (offline) return;

    let cancelled = false;
    async function loadWishlist() {
      try {
        const w = await api.getWishlist(currentUser._id);
        if (!cancelled) setWishlist(w);
      } catch (err) {
        if (!cancelled) {
          setWishlist([]);
          setFeedbackMessage(err.message || "Could not load your wishlist.");
        }
      }
    }
    loadWishlist();
    return () => {
      cancelled = true;
    };
  }, [currentUser, offline]);

  const isWishlisted = useCallback(
    (productId) => wishlist.some((w) => (w.product?._id || w.product) === productId),
    [wishlist]
  );

  const toggleWishlist = useCallback(
    async (product) => {
      if (offline) {
        // local-only toggle when there's no backend connected
        const wasWishlisted = isWishlisted(product._id);
        setWishlist((prev) =>
          wasWishlisted
            ? prev.filter((w) => (w.product?._id || w.product) !== product._id)
            : [...prev, { _id: `local-${product._id}`, product }]
        );
        showItemMessage(product._id, wasWishlisted ? "Removed from wishlist (offline)." : "Added to wishlist (offline).");
        return;
      }
      if (!userId) {
        showItemMessage(product._id, "Sign in on the Profile page first.");
        return;
      }
      try {
        if (isWishlisted(product._id)) {
          await api.removeFromWishlist(userId, product._id);
          setWishlist((prev) => prev.filter((w) => (w.product?._id || w.product) !== product._id));
          showItemMessage(product._id, `Removed ${product.name} from wishlist.`);
        } else {
          const created = await api.addToWishlist(userId, product._id);
          setWishlist((prev) => [...prev, created]);
          showItemMessage(product._id, `Added ${product.name} to wishlist.`);
        }
      } catch (err) {
        console.error("Wishlist update failed:", err.message);
        showItemMessage(product._id, err.message || "Wishlist update failed.");
      }
    },
    [offline, isWishlisted, userId, showItemMessage]
  );

  const login = useCallback(async (profile) => {
    const user = await api.loginProfile(profile);
    setCurrentUser(user);
    setFeedbackMessage("");
    return user;
  }, []);

  // Demo “Google” login (email-based upsert on backend)
  const googleLogin = useCallback(async (googleProfile) => {
    const user = await api.googleLogin(googleProfile);
    setCurrentUser(user);
    setFeedbackMessage("");
    return user;
  }, []);


  const updateProfile = useCallback(
    async (profile) => {
      if (!currentUser?._id) return login(profile);
      const user = await api.updateProfile(currentUser._id, profile);
      setCurrentUser(user);
      return user;
    },
    [currentUser, login]
  );

  const placeOrder = useCallback(async () => {
    if (!currentUser?._id) throw new Error("Sign in first to place an order.");

    if (offline) {
      // demo fallback: clear cart locally in DB if possible
      await api.clearCart(currentUser._id);
      return { demo: true };
    }

    const order = await placeOrderApi(currentUser._id);
    await api.clearCart(currentUser._id);
    return order;
  }, [offline, currentUser]);

  const logout = useCallback(() => {
    setCurrentUser(null);
    setWishlist([]);
    setFeedbackMessage("");
  }, []);

  const deleteAccount = useCallback(async () => {

    if (!currentUser?._id) return;
    await api.deleteProfile(currentUser._id);
    setCurrentUser(null);
    setWishlist([]);
    setFeedbackMessage("Your account was deleted.");
  }, [currentUser]);

  const value = {
    products,
    categories,
    wishlist,
    isWishlisted,
    toggleWishlist,
    getItemMessage,
    showItemMessage,
    feedbackMessage,
    setFeedbackMessage,
    offline,
    loading,
    currentUser,
    userId,
    login,
    updateProfile,
    logout,
    deleteAccount,
    googleLogin,

    // Cart API (syncs to backend when signed in)
    getProduct: api.getProduct,
    getCart: api.getCart,
    addToCart: api.addToCart,
    removeFromCart: api.removeFromCart,
    updateCartQty: api.updateCartQty,
    clearCart: api.clearCart,

    // Orders
    placeOrder,
    getOrdersForUser: api.getOrdersForUser,
  }; 





  return <ShopContext.Provider value={value}>{children}</ShopContext.Provider>;
}

export function useShop() {
  const ctx = useContext(ShopContext);
  if (!ctx) throw new Error("useShop must be used inside a ShopProvider");
  return ctx;
}
