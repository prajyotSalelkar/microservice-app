const express = require("express");
const crypto = require("crypto");
const axios = require("axios");
const router = express.Router();
const Payment = require("../models/Payment");

const CART_SERVICE_URL = process.env.CART_SERVICE_URL || "http://localhost:5003";
const ORDER_SERVICE_URL = process.env.ORDER_SERVICE_URL || "http://localhost:5004";

// Fake gateway call. Swap this out for real Razorpay/Stripe later -
// everything else in this route stays the same.
function mockChargeCard(amount) {
  const success = amount > 0; // always "succeeds" for a valid cart in this demo
  return {
    success,
    transactionId: "txn_" + crypto.randomBytes(8).toString("hex"),
  };
}

// POST /api/checkout  { userId, method }
// This is the front door for "Pay". It talks to cart-service and
// order-service over HTTP, since payment-service does NOT share their
// Mongoose models - this is genuine service-to-service communication.
router.post("/", async (req, res) => {
  const { userId, method } = req.body;
  if (!userId) return res.status(400).json({ message: "userId is required" });

  try {
    // 1. Ask cart-service for the current cart/total
    const { data: cart } = await axios.get(`${CART_SERVICE_URL}/api/cart/${userId}`);
    if (!cart || !cart.items || cart.items.length === 0) {
      return res.status(400).json({ message: "Cart is empty" });
    }

    const amount = Number(cart.total || 0);

    // 2. Charge the "card" (mocked)
    const charge = mockChargeCard(amount);

    if (!charge.success) {
      await Payment.create({
        user: userId,
        amount,
        method: method || "mock_card",
        status: "failed",
        transactionId: charge.transactionId,
      });
      return res.status(402).json({ message: "Payment failed" });
    }

    // 3. Payment succeeded -> ask order-service to actually create the
    //    order and clear the cart (it already owns that logic).
    const { data: order } = await axios.post(`${ORDER_SERVICE_URL}/api/orders`, {
      userId,
    });

    // 4. Record the payment, linked to the order it paid for
    const payment = await Payment.create({
      user: userId,
      order: order._id,
      amount,
      method: method || "mock_card",
      status: "completed",
      transactionId: charge.transactionId,
    });

    res.status(201).json({ payment, order });
  } catch (err) {
    const upstreamMessage = err.response?.data?.message;
    res.status(500).json({ message: upstreamMessage || err.message });
  }
});

// GET /api/checkout/:userId - payment history for a user
router.get("/:userId", async (req, res) => {
  try {
    const payments = await Payment.find({ user: req.params.userId }).sort({
      createdAt: -1,
    });
    res.json(payments);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
