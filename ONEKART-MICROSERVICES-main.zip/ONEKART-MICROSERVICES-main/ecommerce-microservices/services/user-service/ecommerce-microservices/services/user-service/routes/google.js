const express = require("express");
const router = express.Router();
const User = require("../models/User");

// Demo-friendly Google sign-in.
// In a real app, you'd use OAuth + token verification.
// Here we accept { email, name, avatar, bio } and upsert a user.
//
// POST /api/google/login
// body: { email: string, name?: string, avatar?: string, bio?: string }
router.post("/login", async (req, res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const name = String(req.body.name || "").trim();

    if (!email) return res.status(400).json({ error: "Email is required" });

    let user = await User.findOne({ email });
    if (!user) {
      user = await User.create({
        name: name || email.split("@")[0],
        email,
        avatar: String(req.body.avatar || ""),
        bio: String(req.body.bio || ""),
      });
    } else {
      // keep user but refresh name/avatar/bio if provided
      user.name = name || user.name;
      if (req.body.avatar !== undefined) user.avatar = req.body.avatar;
      if (req.body.bio !== undefined) user.bio = req.body.bio;
      await user.save();
    }

    res.json(user);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;

