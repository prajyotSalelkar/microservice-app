const express = require("express");
const router = express.Router();
const Wishlist = require("../models/Wishlist");
require("../models/Product");

// GET /api/wishlist/:userId - list a user's wishlist (with product details)
router.get("/:userId", async (req, res) => {
  try {
    const items = await Wishlist.find({ user: req.params.userId }).populate("product");
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/wishlist - add a product to a user's wishlist
// body: { user: userId, product: productId }
router.post("/", async (req, res) => {
  try {
    const item = await Wishlist.create(req.body);
    const populated = await item.populate("product");
    res.status(201).json(populated);
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ error: "Already in wishlist" });
    }
    res.status(400).json({ error: err.message });
  }
});

// DELETE /api/wishlist/:id - remove a wishlist entry by its own id
router.delete("/:id", async (req, res) => {
  try {
    const item = await Wishlist.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ error: "Wishlist item not found" });
    res.json({ message: "Removed from wishlist" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/wishlist/:userId/:productId - remove by user+product pair
router.delete("/:userId/:productId", async (req, res) => {
  try {
    const item = await Wishlist.findOneAndDelete({
      user: req.params.userId,
      product: req.params.productId,
    });
    if (!item) return res.status(404).json({ error: "Wishlist item not found" });
    res.json({ message: "Removed from wishlist" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
