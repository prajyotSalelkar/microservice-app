 const express = require("express");
const router = express.Router();
const Cart = require("../models/Cart");
const Product = require("../models/Product");

function assertUserId(req, res) {
  const userId = req.params.userId || req.body.userId;
  if (!userId) {
    res.status(400).json({ error: "userId is required" });
    return null;
  }
  return String(userId);
}

// GET /api/cart/:userId
// returns populated items with totals
router.get("/:userId", async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.params.userId }).populate("items.product");
    if (!cart) return res.json({ user: req.params.userId, items: [], total: 0 });

    const items = (cart.items || []).map((it) => ({
      product: it.product,
      quantity: it.quantity,
    }));

    const total = items.reduce((sum, it) => sum + (it.product?.price || 0) * it.quantity, 0);
    res.json({ user: cart.user, items, total });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/cart/add
// body: { userId, productId, quantity? }
router.post("/add", async (req, res) => {
  try {
    const userId = assertUserId(req, res);
    if (!userId) return;

    const productId = req.body.productId;
    const quantity = Math.max(1, Number(req.body.quantity || 1));
    if (!productId) return res.status(400).json({ error: "productId is required" });

    const product = await Product.findById(productId);
    if (!product) return res.status(404).json({ error: "Product not found" });

    let cart = await Cart.findOne({ user: userId });
    if (!cart) {
      cart = await Cart.create({ user: userId, items: [{ product: productId, quantity }] });
    } else {
      const existing = cart.items.find((i) => String(i.product) === String(productId));
      if (existing) existing.quantity += quantity;
      else cart.items.push({ product: productId, quantity });
      await cart.save();
    }

    const populated = await Cart.findOne({ user: userId }).populate("items.product");
    const items = (populated.items || []).map((it) => ({
      product: it.product,
      quantity: it.quantity,
    }));
    const total = items.reduce((sum, it) => sum + (it.product?.price || 0) * it.quantity, 0);

    res.status(201).json({ user: userId, items, total });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// POST /api/cart/remove
// body: { userId, productId }
router.post("/remove", async (req, res) => {
  try {
    const userId = assertUserId(req, res);
    if (!userId) return;

    const productId = req.body.productId;
    if (!productId) return res.status(400).json({ error: "productId is required" });

    const cart = await Cart.findOne({ user: userId });
    if (!cart) return res.json({ user: userId, items: [], total: 0 });

    cart.items = cart.items.filter((it) => String(it.product) !== String(productId));
    await cart.save();

    const populated = await Cart.findOne({ user: userId }).populate("items.product");
    const items = (populated.items || []).map((it) => ({
      product: it.product,
      quantity: it.quantity,
    }));
    const total = items.reduce((sum, it) => sum + (it.product?.price || 0) * it.quantity, 0);

    res.json({ user: userId, items, total });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/cart/update-qty
// body: { userId, productId, quantity }
router.post("/update-qty", async (req, res) => {
  try {
    const userId = assertUserId(req, res);
    if (!userId) return;

    const productId = req.body.productId;
    const quantity = Number(req.body.quantity);

    if (!productId) return res.status(400).json({ error: "productId is required" });
    if (!Number.isFinite(quantity) || quantity < 1) return res.status(400).json({ error: "quantity must be >= 1" });

    const cart = await Cart.findOne({ user: userId });
    if (!cart) return res.status(404).json({ error: "Cart not found" });

    const item = cart.items.find((it) => String(it.product) === String(productId));
    if (!item) return res.status(404).json({ error: "Item not found" });

    item.quantity = quantity;
    await cart.save();

    const populated = await Cart.findOne({ user: userId }).populate("items.product");
    const items = (populated.items || []).map((it) => ({
      product: it.product,
      quantity: it.quantity,
    }));
    const total = items.reduce((sum, it) => sum + (it.product?.price || 0) * it.quantity, 0);

    res.json({ user: userId, items, total });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/cart/clear
// body: { userId }
router.post("/clear", async (req, res) => {
  try {
    const userId = assertUserId(req, res);
    if (!userId) return;

    const cart = await Cart.findOne({ user: userId });
    if (!cart) return res.json({ user: userId, items: [], total: 0 });

    cart.items = [];
    await cart.save();

    res.json({ user: userId, items: [], total: 0 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

