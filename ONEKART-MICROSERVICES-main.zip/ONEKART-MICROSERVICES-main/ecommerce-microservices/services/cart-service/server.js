require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const cartRoutes = require("./routes/cart");

const app = express();
const SERVICE_NAME = "cart-service";

app.use(cors({ origin: process.env.CORS_ORIGIN || "*", credentials: true }));
app.use(express.json());

app.use((req, res, next) => {
  console.log(`[${SERVICE_NAME}] ${req.method} ${req.originalUrl}`);
  next();
});

app.get("/health", (req, res) => {
  res.json({ service: SERVICE_NAME, status: "ok", uptime: process.uptime() });
});

app.get("/", (req, res) => res.send(`${SERVICE_NAME} is running`));

app.use("/api/cart", cartRoutes);

const PORT = process.env.PORT || 5003;
const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/ecommerce";

mongoose
  .connect(MONGO_URI, { serverSelectionTimeoutMS: 5000 })
  .then(() => console.log(`[${SERVICE_NAME}] Connected to MongoDB`))
  .catch((err) => {
    console.error(`[${SERVICE_NAME}] MongoDB connection error:`, err.message);
    console.log(`[${SERVICE_NAME}] Starting without a DB connection.`);
  });

app.listen(PORT, () =>
  console.log(`[${SERVICE_NAME}] listening on http://localhost:${PORT}`)
);
