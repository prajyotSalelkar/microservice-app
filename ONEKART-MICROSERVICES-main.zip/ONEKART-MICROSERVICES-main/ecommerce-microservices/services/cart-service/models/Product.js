const mongoose = require("mongoose");

const productSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    description: { type: String, default: "" },
    price: { type: Number, required: true, min: 0 },
    image: { type: String, default: "" },
    category: { type: String, required: true, trim: true, index: true },
    stock: { type: Number, default: 20, min: 0 },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Product", productSchema);
